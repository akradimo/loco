<?php include '../includes/header.php'; ?>
<div class="container">
    <h1>به برنامه جستجو خطای قطار خوش آمدید</h1>
    <p>این برنامه به شما کمک می‌کند تا خطاهای لوکوموتیو را مدیریت کنید.</p>
</div>
<?php include '../includes/footer.php'; ?>