<?php
include '../includes/auth.php';
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تعمیرات</title>
    <link rel="stylesheet" href="/loco/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/loco/assets/css/custom.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">تعمیرات</h2>
        <p class="text-center">سیستم در حال تعمیرات است. لطفاً بعداً تلاش کنید.</p>
    </div>
</body>
</html>