<?php
include '../includes/auth.php';

// فقط مدیران می‌توانند به این صفحه دسترسی داشته باشند
if (!$_SESSION['is_admin']) {
    header("Location: /loco/pages/access_denied.php");
    exit();
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $backup_file = '../backups/backup-' . date('Y-m-d-H-i-s') . '.sql';
    $command = "mysqldump --user={$username} --password={$password} --host={$host} {$dbname} > {$backup_file}";
    exec($command);

    $success_message = "پشتیبان با موفقیت ایجاد شد.";
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پشتیبان‌گیری</title>
    <link rel="stylesheet" href="/loco/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/loco/assets/css/custom.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center mb-4">پشتیبان‌گیری</h2>
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form method="post">
            <button type="submit" class="btn btn-primary">ایجاد پشتیبان</button>
        </form>
    </div>
    <?php include '../includes/footer.php'; ?>
</body>
</html>