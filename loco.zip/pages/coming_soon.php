<?php
include '../includes/auth.php';
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>به زودی</title>
    <link rel="stylesheet" href="/loco/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="/loco/assets/css/custom.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">به زودی</h2>
        <p class="text-center">این صفحه به زودی راه‌اندازی می‌شود.</p>
    </div>
</body>
</html>