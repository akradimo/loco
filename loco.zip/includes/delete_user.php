<?php
include '../includes/auth.php';

if (!$_SESSION['is_admin']) {
    header("Location: /loco/pages/access_denied.php");
    exit();
}

include '../includes/db.php';

$user_id = $_GET['id'] ?? null;
if (!$user_id) {
    header("Location: /loco/pages/list_users.php");
    exit();
}

// حذف کاربر از دیتابیس
$stmt = $conn->prepare("DELETE FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $user_id]);

header("Location: /loco/pages/list_users.php?success=1");
exit();
?>