<?php
include '../includes/auth.php';

if (!$_SESSION['can_delete_error']) {
    header("Location: /loco/pages/access_denied.php");
    exit();
}

include '../includes/db.php';

$error_id = $_GET['id'] ?? null;
if (!$error_id) {
    header("Location: /loco/pages/list_errors.php");
    exit();
}

// ثبت تاریخچه تغییرات
$stmt = $conn->prepare("
    INSERT INTO error_history (error_id, user_id, change_type, change_details) 
    VALUES (:error_id, :user_id, 'حذف', 'خطا حذف شد')
");
$stmt->execute([
    'error_id' => $error_id,
    'user_id' => $_SESSION['user_id']
]);

// حذف خطا از دیتابیس
$stmt = $conn->prepare("DELETE FROM errors WHERE id = :error_id");
$stmt->execute(['error_id' => $error_id]);

header("Location: /loco/pages/list_errors.php?success=1");
exit();
?>