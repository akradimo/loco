<?php
include '../includes/auth.php';

if (!$_SESSION['can_delete_group']) {
    header("Location: /loco/pages/access_denied.php");
    exit();
}

include '../includes/db.php';

$group_id = $_GET['id'] ?? null;
if (!$group_id) {
    header("Location: /loco/pages/list_groups.php");
    exit();
}

// حذف گروه از دیتابیس
$stmt = $conn->prepare("DELETE FROM error_groups WHERE id = :group_id");
$stmt->execute(['group_id' => $group_id]);

header("Location: /loco/pages/list_groups.php?success=1");
exit();
?>