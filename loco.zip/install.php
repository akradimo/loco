<?php
$host = 'localhost'; // آدرس سرور دیتابیس
$dbname = 'loco';    // نام دیتابیس
$username = 'root';  // نام کاربری دیتابیس
$password = '';      // رمز عبور دیتابیس

try {
    $conn = new PDO("mysql:host=$host", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ایجاد دیتابیس
    $conn->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->exec("USE $dbname");

    // ایجاد جدول کاربران
    $conn->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL,
            password VARCHAR(255) NOT NULL,
            fullname VARCHAR(100),
            province VARCHAR(50),
            city VARCHAR(50),
            station_code VARCHAR(50),
            national_code VARCHAR(10),
            personnel_code VARCHAR(10),
            profile_image VARCHAR(255),
            is_admin BOOLEAN DEFAULT FALSE,
            is_approved BOOLEAN DEFAULT FALSE,
            can_add_error BOOLEAN DEFAULT FALSE,
            can_edit_error BOOLEAN DEFAULT FALSE,
            can_add_group BOOLEAN DEFAULT FALSE,
            can_edit_group BOOLEAN DEFAULT FALSE
        )
    ");

    // ایجاد جدول خطاها
    $conn->exec("
        CREATE TABLE IF NOT EXISTS errors (
            id INT AUTO_INCREMENT PRIMARY KEY,
            error_code VARCHAR(50) NOT NULL,
            error_name VARCHAR(100) NOT NULL,
            group_id INT,
            description TEXT,
            province VARCHAR(50),
            city VARCHAR(50),
            created_at DATE,
            attachment VARCHAR(255),
            FOREIGN KEY (group_id) REFERENCES error_groups(id)
        )
    ");

    // ایجاد جدول گروه‌ها
    $conn->exec("
        CREATE TABLE IF NOT EXISTS error_groups (
            id INT AUTO_INCREMENT PRIMARY KEY,
            group_name VARCHAR(100) NOT NULL
        )
    ");

    echo "دیتابیس و جداول با موفقیت ایجاد شدند.";
} catch (PDOException $e) {
    echo "خطا: " . $e->getMessage();
}
?>