document.addEventListener('DOMContentLoaded', function () {
    // کدهای JavaScript مربوط به صفحه
});